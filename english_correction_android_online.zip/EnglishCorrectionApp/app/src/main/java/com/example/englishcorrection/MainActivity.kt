package com.example.englishcorrection

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var inputText: EditText
    private lateinit var sendBtn: Button
    private lateinit var originalText: TextView
    private lateinit var correctedText: TextView
    private lateinit var progressBar: ProgressBar

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputText = findViewById(R.id.inputText)
        sendBtn = findViewById(R.id.sendBtn)
        originalText = findViewById(R.id.originalText)
        correctedText = findViewById(R.id.correctedText)
        progressBar = findViewById(R.id.progressBar)

        sendBtn.setOnClickListener {
            val text = inputText.text.toString().trim()
            if (text.isNotEmpty()) {
                callLanguageTool(text)
            }
        }
    }

    private fun callLanguageTool(text: String) {
        runOnUiThread { progressBar.visibility = View.VISIBLE }
        originalText.text = text
        correctedText.text = ""

        val formBody = FormBody.Builder()
            .add("language", "en-US")
            .add("text", text)
            .build()

        val request = Request.Builder()
            .url("https://api.languagetool.org/v2/check")
            .post(formBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    correctedText.text = "Network error: " + e.message
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    runOnUiThread {
                        progressBar.visibility = View.GONE
                        correctedText.text = "API error: " + response.code
                    }
                    return
                }

                try {
                    val json = JSONObject(body)
                    val matches = json.getJSONArray("matches")
                    val corrected = applyCorrections(text, matches)
                    runOnUiThread {
                        progressBar.visibility = View.GONE
                        correctedText.text = corrected + "\n\n(Suggestions: " + matches.length() + ")"
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        progressBar.visibility = View.GONE
                        correctedText.text = "Parse error: " + e.message
                    }
                }
            }
        })
    }

    private fun applyCorrections(original: String, matches: JSONArray): String {
        try {
            data class Replacement(val start: Int, val end: Int, val replacement: String)
            val list = ArrayList<Replacement>()

            for (i in 0 until matches.length()) {
                val m = matches.getJSONObject(i)
                val offset = m.getInt("offset")
                val length = m.getInt("length")
                val replacements = m.getJSONArray("replacements")
                if (replacements.length() > 0) {
                    val rep = replacements.getJSONObject(0).getString("value")
                    list.add(Replacement(offset, offset + length, rep))
                }
            }

            list.sortByDescending { it.start }

            val sb = StringBuilder(original)
            for (r in list) {
                if (r.start >= 0 && r.end <= sb.length) {
                    sb.replace(r.start, r.end, r.replacement)
                }
            }
            return sb.toString()
        } catch (e: Exception) {
            return original
        }
    }
}
